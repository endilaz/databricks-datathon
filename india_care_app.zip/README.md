# Find the right care — Databricks App prototype

This Streamlit app ranks facilities within 100 miles of a PIN, city/district-and-state, or entered coordinate location. It uses the provided Virtue Foundation export and PIN directory and can run as a Databricks App. It does not diagnose symptoms or verify current service availability.

## Languages

The top-right language menu currently includes English (default), Assamese, Bengali, Bodo, Dogri, Gujarati, and Hindi, each labeled in its own language and English. The app bundles translated interface text, symptom and procedure menus, result explanations, and weakness descriptions. It does not need a translation API key at runtime. Proper names, addresses, links, and original extracted source quotations remain in their source form so users can verify the underlying record.

Sarvam Translate supports all 22 scheduled Indian languages, but the provided API account returned `No credits available` after these six language packs were completed. The remaining languages are deliberately absent from the menu until their translations can be generated and reviewed. Machine-translated health terms should receive native-speaker review before use in patient-facing care navigation.

## Run

1. Keep `app.py`, `ranking.py`, `app.yaml`, `requirements.txt`, and the root-level `.txt` data files together.
2. Install `requirements.txt`, then run `streamlit run app.py` locally, or upload/deploy the folder as a Databricks App. The included `app.yaml` uses Databricks' documented Streamlit command.
3. Enter a six-digit PIN, both a city/district and state/union territory, or coordinates. Symptoms and a named procedure are both optional; select either, both, or neither.

## Location lookup

The supplied `india_post_pincode_directory-2026-11-22.csv` has 165,627 post-office rows and 19,586 distinct valid PINs. Of these, 19,550 have usable coordinates. The app also retains 119 facility-derived PIN locations that lack usable postal coordinates, for **19,669 searchable PINs** in total. It estimates each PIN center from the median post-office coordinates, so this is an approximate search origin rather than the user's address. A small number of PINs in the file have no usable location; use city/district and state or entered coordinates in those cases.

City names are inferred from facility records and checked against the supplied PIN directory; districts are inferred from the directory. The place index contains 1,684 city/district-and-state pairs across 36 states and union territories. It provides approximate centers, not street addresses, and cannot resolve every locality. When both PIN and city/state are entered, the PIN determines the search origin. If the state conflicts with the PIN directory, the app shows a warning.

The app excludes 317 facility records whose coordinates differ by more than 100 miles from their PIN's postal center. This conservative check avoids ranking clear location conflicts. It can also omit a valid facility when the source PIN or postal coordinates are wrong.

## Optional procedure filter

The cleaned CSV's `procedure` column contains 163,791 nonempty entries and about 89,000 distinct exact strings. Many entries are full sentences or unrelated web-text fragments. This prototype uses a conservative catalog of 52 named procedures and groups clear wording variants (for example, `root canal`, `root canal treatment`, and `RCT`). The catalog covers 4,904 of the 7,882 loaded facility records. These counts describe extracted claims, not verified services.

When a procedure is selected, `rank_facilities()` excludes facilities without a matching catalog tag **before** calculating the ranking. It shows the exact extracted text used for each match. The procedure is a strict eligibility filter and does not add points to the 100-point score. If no procedure is selected, ranking works as before.

Procedure matching deliberately skips obvious negations and research/training text, but the source may still include claims for another facility. The list is incomplete and a missing match does not prove that a facility cannot perform a procedure. Verify the procedure, current availability, and appropriate referral directly with the facility before using this for real care decisions.

## Scoring

Only facilities with internally consistent candidate coordinates and a provisional primary, secondary, or tertiary label are included. The 100-mile radius is strict.

- Distance, 0–40: `40 × (1 − distance_miles/100)`.
- Specialty, 0–40: the teammate's trained `SemanticResidualMLP` checkpoint scores each facility for each of the 148 menu symptoms. The model combines IDF-weighted mapped-specialty coverage with a learned correction. Its raw score is divided by its learned positive scale, bounded to 0–1, then multiplied by 40. For multiple symptoms, the app averages their model scores with severity weights 1/2/3 for Low/Medium/High. These weights apply only when combining separate predictions; the model itself was trained on single-symptom examples.
- Level, 0–20: based on the maximum reported severity:

| Maximum severity | Primary | Secondary | Tertiary |
| --- | ---: | ---: | ---: |
| Low | 20 | 12 | 6 |
| Medium | 8 | 20 | 14 |
| High | 2 | 12 | 20 |

If no symptoms are selected, every facility receives 40/40 for specialty fit and 20/20 for level fit because there is no symptom or severity to compare. After any procedure filter, distance determines the order. The score and its component metrics remain visible, but the plain-language “Why” explanation contains no scores or arrow notation.

The app bundles the teammate checkpoint's predictions in `specialty_model_scores_gzip.txt`, aligned to the facility IDs, and verifies that alignment at startup. `specialty_model_manifest.txt` records the source commit, checkpoint SHA-256, scaling rule, symptom order, and limitations. Runtime needs only Streamlit, not PyTorch. If the facility records, specialties, symptom list, or checkpoint change, regenerate the score table before deployment. The source is the [`feat/facilities-specialty-model` branch](https://github.com/endilaz/databricks-datathon/tree/feat/facilities-specialty-model), commit `6d827fc285ec05592a9f43bce956e96b7bdf3dbf`.

The score is a project rubric, not a clinical probability. The specialty model was trained on provisional AI ratings of a hospital subset, not clinician-reviewed outcomes. Applying it to other facility types and combining its single-symptom predictions are extrapolations. High self-reported severity alone does not prove tertiary care is needed.

## Evidence and limitations

Each result shows its score breakdown, matched extracted specialty names, matching procedure text when selected, source-text excerpt, associated source URLs, address, phone, email, and data weaknesses. Source URLs and text have not been individually verified; some source records merge different facilities. The app therefore labels claims as provisional and should not be used for live patient routing until facilities and clinical rules are validated.

The source data contains no dependable real-time opening hours, emergency readiness, or service availability. The supplied postal directory and facility city labels have not been independently verified, so a user should confirm the location and facility details before travel.

## Verification

The bundled score table was checked against 25 direct checkpoint predictions. Local data checks covered PIN and city/district lookup, score row alignment, the no-symptom rule, multiple symptoms, procedure filtering, and the postal conflict exclusion. The Streamlit UI was not exercised in a browser in this workspace; test the deployed app with real PIN and city/state searches before demonstration.

Sources: [project brief](https://docs.google.com/document/d/e/2PACX-1vQxhDNQmgZhPgjG0M6LCb_UXNV8CJryqBNQQuqWfIg_dm40ZU1AYAXzZKViC6haFoCmLNiRVfUSBMjf/pub), [Databricks Apps](https://docs.databricks.com/aws/en/dev-tools/databricks-apps/tutorial-streamlit), [Sarvam Translate](https://docs.sarvam.ai/api/api-guides-tutorials/models/sarvam-translate).

## Databricks Workspace import

Import `india_care_app_workspace_flat.zip` into an empty Workspace folder. Every archive entry is at the ZIP root and every data file is text. The two large JSON datasets are gzip-compressed, then base64-encoded into `.txt` files; `app.py` decodes them at startup. After import, verify that `app.py`, `app.yaml`, `requirements.txt`, `facilities_gzip.txt`, and `locale_en-IN.txt` appear in the same folder. Deploy the app from that exact folder.
